#ifndef BOOST_STACK_TRACE_HPP_
#define BOOST_STACK_TRACE_HPP_

#include <vector>
#include <string>
namespace boost
{
namespace stack_trace
{


class element
{
private:
    const char* file_;
    unsigned int line_;
    const char* tag_;
public:
    const char* file() const { return file_; }
    unsigned int line() const { return line_; }
    const char* tag() const { return tag_; }
    element(const char* file, unsigned int line, const char* tag)
        : file_(file), line_(line), tag_(tag)
    {
    }
};

std::vector<element const *> const & get();
std::string to_string();


namespace detail
{

class scoped_trace
{
public:
    scoped_trace(element const * current_function);
    ~scoped_trace();
};
}// detail

}// stack_trace
}// boost

#define BOOST_STACK_ELEMENT(file, line, tag)                                    \
    static const ::boost::stack_trace::element _element(file, line, tag); \
    ::boost::stack_trace::detail::scoped_trace _scoped_trace(&_element);  \
    /*BOOST_STACK_ELEMENT*/

#ifdef __GNUC__
#define BOOST_STACK_TRACE_CALL BOOST_STACK_ELEMENT(__FILE__, __LINE__, __func__)
#elif defined(_MSC_VER)
#define BOOST_STACK_TRACE_CALL BOOST_STACK_ELEMENT(__FILE__, __LINE__, __FUNCTION__)
#endif

#define BOOST_STACK_TRACE_TAG(tag) BOOST_STACK_ELEMENT(__FILE__, __LINE__, tag)



#endif
