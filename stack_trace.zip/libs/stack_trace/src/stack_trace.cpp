#include <boost/thread/tss.hpp>
#include <boost/stack_trace.hpp>
#include <sstream>
namespace boost
{
namespace stack_trace
{
namespace
{
boost::thread_specific_ptr<std::vector<element const *> > stack_trace_ptr;
}
namespace detail
{
scoped_trace::scoped_trace(element const * current_function)
{
    if(stack_trace_ptr.get() == NULL)
    {
        stack_trace_ptr.reset(new std::vector<element const *>);
    }
    stack_trace_ptr->push_back(current_function);
}
scoped_trace::~scoped_trace()
{
    stack_trace_ptr->pop_back();
}

}
std::vector<element const *> const & get()
{
    if(stack_trace_ptr.get() == NULL)
    {
        stack_trace_ptr.reset(new std::vector<element const *>);
    }
    return *stack_trace_ptr;
}
std::string to_string()
{
    ::std::stringstream ss;
    ::std::vector<element const *> const & st = get();
    for(::std::size_t i = 0; i < st.size(); i++)
    {
        ss << st[i]->tag() << " at " << st[i]->file() << ":" << st[i]->line() << '\n';
    }
    return ss.str();
}
}
}
