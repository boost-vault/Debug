#include <boost/stack_trace.hpp>
#include <iostream>
#include <sstream>
using namespace boost;
using namespace std;

class exception_with_stack_trace : public exception
{
private:
    std::string what_;
public:
    exception_with_stack_trace(const char* file, unsigned int line, const char* func)
    {
        stringstream ss;
        ss << "exception occurred at " << func << " (" << file << ":" << line << ")\n";
        vector<stack_trace::element const *> const & st = stack_trace::get();
        for(size_t i = st.size(); --i != 0; )
        {
            ss << "\tfrom " << st[i]->tag() << " (" << st[i]->file() << ":" << st[i]->line() << ")\n";
        }
        what_ = ss.str();
    }
    virtual exception_with_stack_trace::~exception_with_stack_trace() throw (){}
    virtual const char * what() const throw ()
    {
        return what_.c_str();
    }
};

void foo(int a)
{
    BOOST_STACK_TRACE_CALL;
    cout << stack_trace::to_string() << endl;
    if(a == 1)
    {
        throw exception_with_stack_trace(__FILE__, __LINE__, __FUNCTION__);
    }

}
void foo()
{   BOOST_STACK_TRACE_CALL;
    foo(0);
    cout << stack_trace::to_string() << endl;
    foo(1);
}
void bar()
{   BOOST_STACK_TRACE_CALL;
    cout << stack_trace::to_string() << endl;
    foo();
    cout << stack_trace::to_string() << endl;
}

int main()
{  
    BOOST_STACK_TRACE_CALL;
    try
    {
        BOOST_STACK_TRACE_TAG("try");
        cout << stack_trace::to_string() << endl;
        foo();
        cout << stack_trace::to_string() << endl;
        bar();
        cout << stack_trace::to_string() << endl;
    }
    catch(exception& e)
    {
        cerr << e.what() << endl;
    }
}
