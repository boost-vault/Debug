#ifndef __EXECUTION_STACK__defined_
#define __EXECUTION_STACK__defined_

#include <list>
#include <iostream>
#include <stdarg.h>
#include "Assert.hpp"
#include "IncludeLog4cplus.hpp"
#include "Mutex.hpp"
#include "MutexLock.hpp"
#include "ThreadLocalStorage.hpp"

/**
 * =========================================================
 * class ExecutionStack
 * --------------------
 * Provides functionality for tracing execution stack
 * of each thread. Especialy usefull for printing stack
 * info when exception occurs.
 * NOTE: it's not regular "gdb" call stack, but a functional
 * stack, requiring to update the context in each relevant
 * function.
 * 
 * In order to disable the feature, DISABLE_STACK_TRACE macro
 * should be defind at compile time.
 * 
 * Functions of ExecutionStack class should not be invoked
 * directly, but using provided macros, explained below.
 * 
 * EXECUTION_STACK_INIT_IN_THREAD
 * Each thread should use this macro on start-up, in order
 * to properly initialize per-thread structires.
 * The natural places to use this macro are:
 * 1) Thread::threadFunc
 * 2) MainThread constructor
 * 
 * TRACE_ENTER_FUNCTION(name)
 * TRACE_ENTER_FUNCTION_FORMAT(format, ...)
 * Should be used at the beginning of each "interesting"
 * function. The name of the function can be specified
 * as const char* string, or using format:
 * - TRACE_ENTER_FUNCTION_FORMAT("MyClass::add(%d)", num);
 * 
 * TRACE_UPDATE_CONTEXT(description)
 * TRACE_UPDATE_CONTEXT_FORMAT(format, ...)
 * Updates current context inside the function, e.g.
 * - TRACE_UPDATE_CONTEXT("parsing HTTP event");
 * Format is used in same way as in
 * TRACE_ENTER_FUNCTION_FORMAT example.
 * 
 * TRACE_LOG_EXCEPTION_STACK(logger)
 * Here "logger" is log4cplus logger (usually defined
 * as LOG static member). Will print whole call stack
 * to the log.
 * 1) The log will be printed as DEBUG, but this messege
 * will be forced, even if log level is higher
 * 2) Current location in stack will be preceeded by '=>'
 * 
 * NOTE: using FORMAT vesions of the macro will affect
 * run-time performance. The length of final string
 * will be limited by 1024 bytes (FUNCTION_CONTEXT_BUF_SIZE)
 * =========================================================
 */


class ExecutionStack {
public:
	virtual ~ExecutionStack(void);

	void writeFullStack(std::ostream &out);


public:
    /**
     * This class manages instances of ExecutionStack class
     * (1 object per thread), when pointer to this object
     * is stored in per-thread-storage.
     * This manager is singleton by itself, and when created
     * for the first time, it initializes static key,
     * used later to access per-thread-storage.
	 */
	class PerThreadStackInfoHandler {
	public:
		static PerThreadStackInfoHandler & GetInstance(void);
		virtual ~PerThreadStackInfoHandler(void);

        /** should be called once in each thread */
		void initExecutionStackInThread(void);

        /** returns ExecutionStack, associated with
        *   current thread */
		// NOTE: assumes "initExecutionStackInThread" was already
		// called in this thread
		static inline ExecutionStack & GetThreadExecutionStack(void);

	private:
		// singleton object
		PerThreadStackInfoHandler(void);
		static PerThreadStackInfoHandler *__instance;
		static Mutex __instanceMutex;

		// per-thread storage
		static ThreadLocatStorage __exec_stack_tls;
		static void CleanupThreadInfo(void *pStack);
	};


	/**
	 * Defines current context of the function
	 */
	class FunctionContext {
	public:
		inline FunctionContext(void): functionName("unknown"), locationDescription("unknown"), locationFile("unknown"), locationLine(0) {}
		inline ~FunctionContext(void) {}

		inline void startFunction(const char *name, const char *file, int line) { functionName = name; locationDescription = "start"; locationFile = file; locationLine = line; }
		inline void formatFunctionName(const char *format, ...);
		inline void setLocation(const char *description, int line) { locationDescription = description; locationLine = line; }
		inline void formatLocation(const char *format, ...);

		inline void writeContext(std::ostream &out) const;

	private:
		// NOTE: functionName and locationDescription strings can
		// be specified in 2 ways:
		// 1) by pointing to global const char* (just using
		//    "string" in the code)
		// 2) by using format, in this case the result will stored
		//    inside "...Buf" buffer, and the "name" pointer
		//    will point to this buffer
		#define FUNCTION_CONTEXT_BUF_SIZE 1024
		const char *functionName;
		char functionNameBuf[FUNCTION_CONTEXT_BUF_SIZE];
		const char *locationDescription;
		char locationDescriptionBuf[FUNCTION_CONTEXT_BUF_SIZE];
		const char *locationFile;
		int locationLine;
	};

public:
	/**
     * This class will make sure that "leaveFunction" is called
     * for each function entered with "enterFunction". For this
     * reason those functions are defind as "private" in
     * ExecutionStack
	 */
	class FunctionContextHandler {
	public:
		inline FunctionContextHandler(ExecutionStack &estack, const char *name, const char *file, int line);
		inline ~FunctionContextHandler(void);

		inline FunctionContext & getContext(void) { return __context; }

	private:
		ExecutionStack &__stack;
		FunctionContext &__context;
	};

private:
	// those functions can be only accessed via FunctionContextHandler class 
	inline FunctionContext & enterFunction(const char *name, const char *file, int line);
	inline void leaveFunction(void);
	friend class FunctionContextHandler;

private:
	// can be allocated by "PerThreadStackInfoHandler"
	// class only
	ExecutionStack(void);
	friend class PerThreadStackInfoHandler;
	
	// the "stack" of FunctionContext objects is
	// managed as linked list. Once allocated,
	// FunctionContext object is never released while
	// the thread is running.
	typedef std::list<FunctionContext*> list_stack_t;
	typedef list_stack_t::iterator iter_list_stack_t;

	// __current_frame is updated each time "enterFunction"
	//   or "leaveFunction" is called
	// __max__frame is called only for "enterFunction"
	//   functions
	// This way in case of exception __max_frame will point
	// to the function which has generated the exception,
	// even if "leaveFunction" was already called.
	list_stack_t __stack;
	unsigned int __numOfAllocatedStacks;
	static const unsigned int MAX_NUMBER_OF_ALLOCATED_STACKS;
	iter_list_stack_t __current_frame;
	iter_list_stack_t __max_frame;
};



/////////////////////////////////////////
// 
// FunctionContext
// inline functions
// 
/////////////////////////////////////////

inline void ExecutionStack::FunctionContext::formatFunctionName(const char *format, ...) {
	va_list params;
	va_start(params, format);
	vsnprintf(functionNameBuf, FUNCTION_CONTEXT_BUF_SIZE, format, params);
	va_end(params);

	functionName = functionNameBuf;
}

inline void ExecutionStack::FunctionContext::formatLocation(const char *format, ...) {
	va_list params;
	va_start(params, format);
	vsnprintf(locationDescriptionBuf, FUNCTION_CONTEXT_BUF_SIZE, format, params);
	va_end(params);

	locationDescription = locationDescriptionBuf;
}


inline void ExecutionStack::FunctionContext::writeContext(std::ostream &out) const {
	out << '\"' << locationDescription << "\" in function \"" << functionName
		<< "\" [" << locationFile << ':' << locationLine << ']';
}


/////////////////////////////////////////
// 
// ExecutionStack
// inline functions
// 
/////////////////////////////////////////


inline ExecutionStack::FunctionContext & ExecutionStack::enterFunction(const char *name, const char *file, int line) {
	__current_frame ++;

	if (__current_frame == __stack.end()) {
		// need to allocate new object
		if (__numOfAllocatedStacks < MAX_NUMBER_OF_ALLOCATED_STACKS) {
			__current_frame = __stack.insert(__current_frame, new FunctionContext);
			__numOfAllocatedStacks ++;
		} else {
			ASSERT(false, "exceeded max number of function frames when entering function \"" << name
							 << "\", [" << file << ':' << ']')
			__current_frame --;
		}
	}
	__max_frame = __current_frame;

	FunctionContext &current = *(*__current_frame);
	current.startFunction(name, file, line);
	return current;
}


inline void ExecutionStack::leaveFunction(void) {
	if (__current_frame != __stack.begin()) {
		__current_frame --;
	} else {
		ASSERT(false, "can't leave more functions than it has entered")
	}
}



/////////////////////////////////////////
// 
// FunctionContextHandler
// inline functions
// 
/////////////////////////////////////////

inline ExecutionStack::FunctionContextHandler::FunctionContextHandler(ExecutionStack &estack, const char *name, const char *file, int line)
: __stack(estack), __context(__stack.enterFunction(name, file, line))
{}

inline ExecutionStack::FunctionContextHandler::~FunctionContextHandler(void) {
	__stack.leaveFunction();
}



/////////////////////////////////////////
// 
// PerThreadStackInfoHandler
// inline functions
// 
/////////////////////////////////////////

// NOTE: initExecutionStackInThread must be called in thread
// before this function is invoked
inline ExecutionStack & ExecutionStack::PerThreadStackInfoHandler::GetThreadExecutionStack(void)
{
	return *(static_cast<ExecutionStack*>(__exec_stack_tls.getThreadValue()));
}




};  // end namespace

/////////////////////////////////////////
// MACROS
/////////////////////////////////////////

#ifndef DISABLE_STACK_TRACE
// stack trace is enabled (default)
	#define EXECUTION_STACK_INIT_IN_THREAD												\
		ExecutionStack::PerThreadStackInfoHandler::GetInstance().initExecutionStackInThread()

	#define TRACE_ENTER_FUNCTION(name) 													\
		ExecutionStack::FunctionContextHandler											\
			__Context_handleR__(ExecutionStack::PerThreadStackInfoHandler::GetThreadExecutionStack(), name, __FILE__, __LINE__)
	
	#define TRACE_ENTER_FUNCTION_FORMAT(format, ...) 									\
		TRACE_ENTER_FUNCTION("");														\
		__Context_handleR__.getContext().formatFunctionName(format, __VA_ARGS__)
	
	#define TRACE_UPDATE_CONTEXT(description)											\
		__Context_handleR__.getContext().setLocation(description, __LINE__)
	
	#define TRACE_UPDATE_CONTEXT_FORMAT(format, ...)									\
		TRACE_UPDATE_CONTEXT("");														\
		__Context_handleR__.getContext().formatLocation(format, __VA_ARGS__)

	#define TRACE_LOG_EXCEPTION_STACK(logger)											\
		{																				\
			log4cplus::tostringstream __log4cplus_buf__;								\
			ExecutionStack::PerThreadStackInfoHandler::GetThreadExecutionStack().writeFullStack(__log4cplus_buf__);				\
			logger.forcedLog(log4cplus::INFO_LOG_LEVEL, __log4cplus_buf__.str(), __FILE__, __LINE__); \
		}
#else
// stack trace is disabled
	#define EXECUTION_STACK_INIT_IN_THREAD
	#define TRACE_ENTER_FUNCTION(name) 
	#define TRACE_ENTER_FUNCTION_FORMAT(format, ...)
	#define TRACE_UPDATE_CONTEXT(description)
	#define TRACE_UPDATE_CONTEXT_FORMAT(format, ...)
	#define TRACE_LOG_EXCEPTION_STACK(logger)
#endif



