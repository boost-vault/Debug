
#include "ExecutionStack.hpp"



////////////////////////////////////////////////////
// 
// ExecutionStack
// Implementation
// 
////////////////////////////////////////////////////


const unsigned int ExecutionStack::MAX_NUMBER_OF_ALLOCATED_STACKS = 128;


/**
 * Constructor.
 * Makes sure there's always at least one "function"
 * in the stack
 */
ExecutionStack::ExecutionStack(void) : __stack(), __numOfAllocatedStacks(0)
{
	__stack.push_back(new FunctionContext);
	__max_frame = __current_frame = __stack.begin();
}


/**
 * Destructor.
 * Is called when the thread exits, releases all
 * "FunctionContext" objects in the list.
 */
ExecutionStack::~ExecutionStack(void)
{
	for (iter_list_stack_t it = __stack.begin(); it != __stack.end(); ++it)
		delete (*it);
	__stack.clear();
}


/**
 * operator <<
 * for "FunctionContext"
 */
std::ostream& operator <<(std::ostream &out, const ExecutionStack::FunctionContext &context)
{
	context.writeContext(out);
	return out;
}


/**
 * Logs full ("exception") call stack
 */
void ExecutionStack::writeFullStack(std::ostream &out)
{
	out << "EXECUTION STACK\n";

	iter_list_stack_t it = __stack.begin();
	ASSERT(it != __stack.end(), "first \"unknown\" element should be never removed")
	it ++;
	while (it != __stack.end()) {
		out << "   " << (it == __current_frame ? "=>" : "") << (**it) << '\n';
		if (it == __max_frame) break;
		it ++;
	}
}



////////////////////////////////////////////////////
// 
// PerThreadStackInfoHandler
// Implementation
// 
////////////////////////////////////////////////////

ExecutionStack::PerThreadStackInfoHandler *ExecutionStack::PerThreadStackInfoHandler::__instance;
Mutex ExecutionStack::PerThreadStackInfoHandler::__instanceMutex;

ThreadLocatStorage ExecutionStack::PerThreadStackInfoHandler::__exec_stack_tls;


/**
 * @return singleton instance of PerThreadStackInfoHandler
 */
ExecutionStack::PerThreadStackInfoHandler & ExecutionStack::PerThreadStackInfoHandler::GetInstance(void)
{
	if (__instance == NULL) {
		// create new instance
		MutexLock lock(__instanceMutex);
		if (__instance == NULL)
			__instance = new PerThreadStackInfoHandler;
	}
	return *__instance;
}


/**
 * PerThreadStackInfoHandler contructor.
 * This class in singleton, and is used to make sure
 * that per-thread key is initialized once in the
 * process.
 */
ExecutionStack::PerThreadStackInfoHandler::PerThreadStackInfoHandler(void)
{
	__exec_stack_tls.initialize(CleanupThreadInfo);
}


/**
 * Destructor.
 * Releases per-thread-data key
 */
ExecutionStack::PerThreadStackInfoHandler::~PerThreadStackInfoHandler(void)
{
	__exec_stack_tls.destroy();
}


/**
 * Initializes ExecutionStack object in thread.
 * This function should be called only once in
 * each thread
 */
void ExecutionStack::PerThreadStackInfoHandler::initExecutionStackInThread(void)
{
	__exec_stack_tls.setThreadValue(static_cast<void*>(new ExecutionStack));
}


/**
 * Deletes ExecutionStack object of this thread
 */
void ExecutionStack::PerThreadStackInfoHandler::CleanupThreadInfo(void *pStack)
{
	delete static_cast<ExecutionStack*>(pStack);
}


